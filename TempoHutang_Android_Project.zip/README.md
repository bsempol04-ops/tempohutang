# TempoHutang Android

Aplikasi Android native untuk mencatat utang dan jatuh tempo.

## Fitur
- Tambah/edit/hapus catatan nama, nominal, tanggal jatuh tempo, catatan.
- Tandai lunas menggunakan checkbox.
- Ringkasan total belum lunas, jatuh tempo hari ini, dan terlambat.
- Filter Semua / Belum lunas / Terlambat / Lunas.
- Ekspor cadangan JSON.
- Pengingat notifikasi harian sekitar pukul 09.00 (bergantung pengaturan baterai/OS Android).

Data disimpan secara lokal di perangkat melalui SharedPreferences. Tidak perlu akun atau internet.

## Menghasilkan APK
Project ini disiapkan untuk build melalui GitHub Actions:
1. Buat repository GitHub baru.
2. Unggah seluruh isi folder project ini ke repository, termasuk folder `.github`.
3. Buka tab **Actions**, pilih **Build TempoHutang APK**, lalu tekan **Run workflow**.
4. Setelah selesai, buka hasil run dan unduh artifact **TempoHutang-debug-apk**.
5. Ekstrak ZIP artifact dan pasang `app-debug.apk` di HP Android. Android mungkin meminta izin memasang aplikasi dari sumber tersebut.

Atau build di komputer yang telah memiliki Android SDK, Java 17, dan Gradle 8.9 dengan perintah `gradle assembleDebug`.

## Catatan
APK belum ditandatangani sebagai rilis Play Store; ini debug APK untuk pemasangan pribadi. Notifikasi bisa dipengaruhi izin notifikasi, optimasi baterai, dan kebijakan perangkat. Selalu buat cadangan sebelum reset atau menghapus data aplikasi.
