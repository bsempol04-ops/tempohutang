package id.tempohutang.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.*

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val prefs=context.getSharedPreferences("tempohutang",Context.MODE_PRIVATE)
        val a=try { JSONArray(prefs.getString("debts","[]")) } catch (_:Exception) { JSONArray() }
        val today=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
        var count=0
        for(i in 0 until a.length()) {
            val o=a.optJSONObject(i) ?: continue
            if(!o.optBoolean("paid") && o.optString("due")<=today) count++
        }
        val manager=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel("tempo_hutang","Pengingat jatuh tempo",NotificationManager.IMPORTANCE_DEFAULT))
        val open=PendingIntent.getActivity(context,0,Intent(context,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val body=if(count>0) "Ada $count catatan belum lunas yang jatuh tempo hari ini atau terlambat." else "Buka TempoHutang untuk memeriksa catatan utangmu."
        val n=if(Build.VERSION.SDK_INT>=26) Notification.Builder(context,"tempo_hutang") else Notification.Builder(context)
        manager.notify(1001,n.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("TempoHutang").setContentText(body).setContentIntent(open).setAutoCancel(true).build())
    }
}
