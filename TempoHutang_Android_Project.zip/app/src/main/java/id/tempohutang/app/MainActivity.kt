package id.tempohutang.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

data class Debt(val id: Long, var person: String, var amount: Long, var due: String, var note: String, var paid: Boolean)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("tempohutang", MODE_PRIVATE) }
    private val debts = mutableListOf<Debt>()
    private lateinit var listBox: LinearLayout
    private lateinit var summary: TextView
    private var filter = "Semua"
    private val green = Color.rgb(23, 107, 77)
    private val pale = Color.rgb(224, 243, 232)
    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun rupiah(n: Long): String = NumberFormat.getCurrencyInstance(Locale("id","ID")).format(n).replace(",00","")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        scheduleReminder(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 22)
        }
        buildUi()
    }
    private fun buildUi() {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(243,246,242)) }
        val header = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,28,22,25); setBackgroundColor(Color.rgb(18,55,42)) }
        header.addView(TextView(this).apply { text="CATATAN KEUANGAN PRIBADI"; textSize=11f; setTextColor(0xFFB9D9C9.toInt()) })
        header.addView(TextView(this).apply { text="TempoHutang"; textSize=28f; setTextColor(Color.WHITE); setTypeface(null,1) })
        header.addView(TextView(this).apply { text="Catat utang, pantau tempo, tandai saat lunas."; textSize=13f; setTextColor(Color.WHITE) })
        outer.addView(header)
        summary = TextView(this).apply { setPadding(16,15,16,15); textSize=14f; setTextColor(Color.rgb(23,35,29)); setBackgroundColor(Color.WHITE) }
        outer.addView(summary)
        val add = Button(this).apply { text="+ Tambah catatan hutang"; setTextColor(Color.WHITE); setBackgroundColor(green); setOnClickListener { editDebt(null) } }
        outer.addView(add, LinearLayout.LayoutParams(-1,-2).apply { setMargins(12,10,12,6) })
        val filterRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        listOf("Semua","Belum lunas","Terlambat","Lunas").forEach { f ->
            filterRow.addView(Button(this).apply {
                text=f; textSize=10f; setPadding(3,2,3,2)
                setOnClickListener { filter=f; render() }
            }, LinearLayout.LayoutParams(0,-2,1f))
        }
        outer.addView(filterRow)
        val scroll = ScrollView(this)
        listBox = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12,4,12,18) }
        scroll.addView(listBox)
        outer.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val backup = Button(this).apply { text="Ekspor cadangan"; setOnClickListener { exportBackup() } }
        outer.addView(backup)
        setContentView(outer)
        render()
    }
    private fun load() {
        debts.clear()
        try {
            val a = JSONArray(prefs.getString("debts","[]"))
            for (i in 0 until a.length()) {
                val o=a.getJSONObject(i)
                debts.add(Debt(o.optLong("id"),o.optString("person"),o.optLong("amount"),o.optString("due"),o.optString("note"),o.optBoolean("paid")))
            }
        } catch (_: Exception) {}
    }
    private fun save() {
        val a=JSONArray()
        debts.forEach { d -> a.put(JSONObject().put("id",d.id).put("person",d.person).put("amount",d.amount).put("due",d.due).put("note",d.note).put("paid",d.paid)) }
        prefs.edit().putString("debts",a.toString()).apply()
        render()
    }
    private fun render() {
        if (!::listBox.isInitialized) return
        val open=debts.filter { !it.paid }
        val late=open.count { it.due < today() }
        val dueToday=open.count { it.due == today() }
        summary.text="Belum lunas: ${rupiah(open.sumOf { it.amount })}   •   ${open.size} catatan\nJatuh tempo hari ini: $dueToday   •   Terlambat: $late"
        listBox.removeAllViews()
        val shown=debts.filter {
            when(filter) { "Belum lunas" -> !it.paid; "Terlambat" -> !it.paid && it.due<today(); "Lunas" -> it.paid; else -> true }
        }.sortedWith(compareBy<Debt> { if (it.paid) 1 else 0 }.thenBy { it.due })
        if(shown.isEmpty()) {
            listBox.addView(TextView(this).apply { text="Belum ada catatan.\nTekan tombol tambah untuk mulai."; gravity=Gravity.CENTER; setPadding(12,40,12,40); textSize=16f })
        }
        shown.forEach { d ->
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,12,14,10); setBackgroundColor(Color.WHITE) }
            val name=TextView(this).apply { text=d.person; textSize=18f; setTextColor(Color.rgb(23,35,29)); setTypeface(null,1) }
            card.addView(name)
            card.addView(TextView(this).apply { text=rupiah(d.amount); textSize=17f; setTextColor(green); setTypeface(null,1) })
            val status=when { d.paid -> "✓ LUNAS"; d.due<today() -> "TERLAMBAT • Tempo $d.due"; d.due==today() -> "JATUH TEMPO HARI INI"; else -> "Jatuh tempo: ${d.due}" }
            card.addView(TextView(this).apply { text=status; textSize=12f; setTextColor(if(d.paid) green else if(!d.paid&&d.due<=today()) Color.rgb(180,35,24) else Color.DKGRAY); setPadding(0,4,0,4) })
            if(d.note.isNotBlank()) card.addView(TextView(this).apply { text=d.note; textSize=13f; setTextColor(Color.DKGRAY) })
            val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            val check=CheckBox(this).apply { text="Lunas"; isChecked=d.paid; setOnCheckedChangeListener { _, checked -> d.paid=checked; save() } }
            actions.addView(check,LinearLayout.LayoutParams(0,-2,1f))
            actions.addView(Button(this).apply { text="Edit"; setOnClickListener { editDebt(d) } })
            actions.addView(Button(this).apply { text="Hapus"; setOnClickListener { AlertDialog.Builder(this@MainActivity).setMessage("Hapus catatan ${d.person}?").setNegativeButton("Batal",null).setPositiveButton("Hapus") { _,_-> debts.removeAll { it.id==d.id }; save() }.show() } })
            card.addView(actions)
            val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,10)
            listBox.addView(card,lp)
        }
    }
    private fun editDebt(old: Debt?) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,4,20,0) }
        fun input(hint:String,value:String="",type:Int=android.text.InputType.TYPE_CLASS_TEXT): EditText {
            return EditText(this).apply { this.hint=hint; setText(value); inputType=type; maxLines=1 }
        }
        val person=input("Nama orang / pihak",old?.person.orEmpty())
        val amount=input("Nominal rupiah",old?.amount?.toString().orEmpty(),android.text.InputType.TYPE_CLASS_NUMBER)
        val due=input("Tanggal jatuh tempo (YYYY-MM-DD)",old?.due?:today())
        val note=input("Catatan (opsional)",old?.note.orEmpty())
        box.addView(person); box.addView(amount); box.addView(due); box.addView(note)
        val picker=Button(this).apply { text="Pilih tanggal dari kalender"; setOnClickListener {
            val cal=Calendar.getInstance()
            try { val p=due.text.toString().split("-"); cal.set(p[0].toInt(),p[1].toInt()-1,p[2].toInt()) } catch (_:Exception) {}
            DatePickerDialog(this@MainActivity,{ _,y,m,d -> due.setText(String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d)) },cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()
        } }
        box.addView(picker)
        AlertDialog.Builder(this).setTitle(if(old==null) "Tambah hutang" else "Edit hutang").setView(box)
            .setNegativeButton("Batal",null).setPositiveButton("Simpan") { _,_ ->
                val n=person.text.toString().trim()
                val a=amount.text.toString().toLongOrNull()
                val date=due.text.toString().trim()
                if(n.isEmpty()||a==null||a<0||!date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
                    Toast.makeText(this,"Isi nama, nominal, dan tanggal YYYY-MM-DD dengan benar.",Toast.LENGTH_LONG).show()
                } else if(old==null) debts.add(Debt(System.currentTimeMillis(),n,a,date,note.text.toString().trim(),false))
                else { old.person=n; old.amount=a; old.due=date; old.note=note.text.toString().trim() }
                save()
            }.show()
    }
    private fun exportBackup() {
        val content=prefs.getString("debts","[]") ?: "[]"
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="application/json"; putExtra(Intent.EXTRA_TITLE,"cadangan-tempohutang.json")
        }
        backupContent=content
        startActivityForResult(i,44)
    }
    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==44 && resultCode==RESULT_OK) {
            try { data?.data?.let { uri -> contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(backupContent) } }; Toast.makeText(this,"Cadangan disimpan",Toast.LENGTH_SHORT).show() }
            catch(_:Exception) { Toast.makeText(this,"Gagal menyimpan cadangan",Toast.LENGTH_SHORT).show() }
        }
    }
    companion object {
        var backupContent="[]"
        fun scheduleReminder(context: Context) {
            val alarm= context.getSystemService(ALARM_SERVICE) as AlarmManager
            val intent=Intent(context,ReminderReceiver::class.java)
            val pi=PendingIntent.getBroadcast(context,1,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val cal=Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,9); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); if(timeInMillis<=System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1) }
            alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pi)
        }
    }
}
